#!/bin/bash

java -jar ../../../xsl/saxon8.jar slides.xml ../../../xsl/softeu-slide.xsl

