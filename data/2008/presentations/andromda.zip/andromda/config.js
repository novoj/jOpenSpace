<?xml version="1.0" encoding="utf-8"?>
		// This is the table of contents. A list of html files that you wish to show as
// a slide, in the order specified in this array.
var toc = new Array(
    'index.html',
    'mda.html',
    'postup.html',
    'mapovani.html',
    'maven.html',
    'maven2.html',
    'ukazka.html',
    'shrnuti-kladna.html',
    'shrnuti-zaporna.html'
);

// directory that contains the mozpoint lib. defaults to .
var libLocation = "./"

// resize the window to a good viewable size
var resizeOnLoad = false;

// using these hints...
var size = 1; // 0 = 800x600, 1 = 1024x768, ...

// ----- FUTURE preferences- Not yet implemented. -----

// directory that contains images for backdrops, effects, etc. defaults to
// libLocation
var imgLocation = "./";

// Automatically advance after each slide (timeout specified in the slide file)
var autoAdvance = 0;

// Select from a standard list of themes
var theme = 0;
		